papers about prompt engineering
